import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-complite-details',
  templateUrl: './my-complite-details.component.html',
  styleUrls: ['./my-complite-details.component.css']
})
export class MyCompliteDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

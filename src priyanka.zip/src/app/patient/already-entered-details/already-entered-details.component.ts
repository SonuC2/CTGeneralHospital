import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-already-entered-details',
  templateUrl: './already-entered-details.component.html',
  styleUrls: ['./already-entered-details.component.css']
})
export class AlreadyEnteredDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

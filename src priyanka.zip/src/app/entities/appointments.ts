export class Appointments {
}

export class Inbox {
}

export class Allergy {

    private allergyId!:string;
    private allergyType!:string;
    private allergyName!:string;
    private allergyDescription!:string;
    private clinicalInformation!:string;
}

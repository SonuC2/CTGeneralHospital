export class EmergencyInfo {

    private firstName!:string;
    private lastName!:string;
    private ralationship!:string;
    private mobileNo!:number;
    private email!:string;
    private address!:string;
    private access!:string;
}

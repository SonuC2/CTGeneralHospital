import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Employee } from 'src/app/entities/employee';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.css']
})
export class InboxComponent implements OnInit {

  sendNoteForm!: any;
  specialisations!: Employee[];
  specialisationControl!:FormControl;

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-submission-dialog',
  templateUrl: './data-submission-dialog.component.html',
  styleUrls: ['./data-submission-dialog.component.css']
})
export class DataSubmissionDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

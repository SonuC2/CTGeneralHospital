import { Inbox } from './inbox';

describe('Inbox', () => {
  it('should create an instance', () => {
    expect(new Inbox()).toBeTruthy();
  });
});

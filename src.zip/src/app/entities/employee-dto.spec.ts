import { EmployeeDTO } from './employee-dto';

describe('EmployeeDTO', () => {
  it('should create an instance', () => {
    expect(new EmployeeDTO()).toBeTruthy();
  });
});

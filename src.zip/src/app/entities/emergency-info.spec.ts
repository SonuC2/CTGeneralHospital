import { EmergencyInfo } from './emergency-info';

describe('EmergencyInfo', () => {
  it('should create an instance', () => {
    expect(new EmergencyInfo()).toBeTruthy();
  });
});

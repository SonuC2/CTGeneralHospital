import { Appointments } from './appointments';

describe('Appointments', () => {
  it('should create an instance', () => {
    expect(new Appointments()).toBeTruthy();
  });
});

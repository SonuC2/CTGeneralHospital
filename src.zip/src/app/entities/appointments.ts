export class Appointments {
}

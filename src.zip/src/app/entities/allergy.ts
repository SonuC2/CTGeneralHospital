export class Allergy {

 allergyId!:string;
 allergyType!:string;
 allergyName!:string;
 allergyDescription!:string;
 clinicalInformation!:string;
}

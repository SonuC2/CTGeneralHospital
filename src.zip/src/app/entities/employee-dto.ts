import { Employee } from "./employee";

export class EmployeeDTO {

    employeeId!: number;
	title!:string;
	firstName!:string;
	lastName!:string;
	specialisation!:string;
    // employees!:Employee[];
}

export class UserRole {
     userRoleId !:number;
     roleType!: string;
}

export class Inbox {

    noteId!: number;
    receiverId!: number;
	receiverName!:string;
	receiverSpecialisation!:string;
	senderId!:number;
	senderName!:string;
	senderSpecialisation!:string;
	messege!:string;
	urgencyLevel!:string;
	responseStatus!:string;
}

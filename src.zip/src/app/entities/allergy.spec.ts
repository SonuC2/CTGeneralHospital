import { Allergy } from './allergy';

describe('Allergy', () => {
  it('should create an instance', () => {
    expect(new Allergy()).toBeTruthy();
  });
});

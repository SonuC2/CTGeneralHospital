export class EmergencyInfo {

 firstName!:string;
 lastName!:string;
 ralationship!:string;
 mobileNo!:number;
 email!:string;
 address!:string;
 access!:string;
}

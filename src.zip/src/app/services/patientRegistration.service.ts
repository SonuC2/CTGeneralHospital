import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PatientRegistration } from '../entities/patient-registration';
// import { PatientRegistration } from '../entities/patientRegistration';

@Injectable({
  providedIn: 'root'
})
export class PatientRegistrationService {

  constructor(private _httpClient:HttpClient) { }

  submitPatientRegDetails(data:PatientRegistration):Observable<PatientRegistration>
  {
    return this._httpClient.post<PatientRegistration>("http://localhost:9004/register-patient",data);
  }

  registerPatient(data:PatientRegistration):Observable<PatientRegistration>{
    return this._httpClient.post<PatientRegistration>("http://localhost:9004/register-patient",data);
  }

  getAllPatientList():Observable<PatientRegistration[]>{
    return this._httpClient.get<PatientRegistration[]>('http://localhost:9004/register-patient' );
  }

}
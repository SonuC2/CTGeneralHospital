import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calender-add-appointment',
  templateUrl: './calender-add-appointment.component.html',
  styleUrls: ['./calender-add-appointment.component.css']
})
export class CalenderAddAppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

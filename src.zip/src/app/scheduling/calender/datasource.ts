export let scheduleData: Object[] = [
    {
        Id: 1,
        Subject: 'Fever Cold Influnza',
        StartTime: new Date(2021,12, 24, 9, 30),
        EndTime: new Date(2021, 12, 24, 11, 0),
        CategoryColor: '#1aaa55',
        isBlock:true
    }, {
        Id: 2,
        Subject: 'Allergy last phase 3',
        StartTime: new Date(2021, 12, 25, 12, 0),
        EndTime: new Date(2021, 12, 25, 14, 0),
        CategoryColor: '#357cd2',
        isReadOnly:true
    }]
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-savedialog',
  templateUrl: './savedialog.component.html',
  styleUrls: ['./savedialog.component.css']
})
export class SavedialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

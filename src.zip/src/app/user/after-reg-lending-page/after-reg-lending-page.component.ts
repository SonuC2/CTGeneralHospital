import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-after-reg-lending-page',
  templateUrl: './after-reg-lending-page.component.html',
  styleUrls: ['./after-reg-lending-page.component.css']
})
export class AfterRegLendingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
